package cat.itb.m07;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button rollTheDice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rollTheDice = findViewById(R.id.button);

        rollTheDice.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                ImageView dice1 = findViewById(R.id.result);
                ImageView dice2 = findViewById(R.id.result2);
                ImageView[] dices = {dice1, dice2};
                int contador;
                int i = 0;

                while (i < dices.length) {
                    contador = (int) (Math.random() * 6 + 1);
                    switch (contador) {
                        case 1:
                            dices[i].setImageResource(R.drawable.dice_1);
                            break;
                        case 2:
                            dices[i].setImageResource(R.drawable.dice_2);
                            break;
                        case 3:
                            dices[i].setImageResource(R.drawable.dice_3);
                            break;
                        case 4:
                            dices[i].setImageResource(R.drawable.dice_4);
                            break;
                        case 5:
                            dices[i].setImageResource(R.drawable.dice_5);
                            break;
                        case 6:
                            dices[i].setImageResource(R.drawable.dice_6);
                            break;
                    }
                    i++;
                }
            }
        });

    }
}