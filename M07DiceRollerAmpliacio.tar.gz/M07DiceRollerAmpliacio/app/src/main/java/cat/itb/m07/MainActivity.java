package cat.itb.m07;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity {

    Button rollTheDice;
    Button reset;
    ImageView dice1;
    ImageView dice2;
    int contador[] = {0,0};
    Toast toast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rollTheDice = findViewById(R.id.buttonRoll);
        reset = findViewById(R.id.buttonReset);
        dice1 = findViewById(R.id.result);
        dice2 = findViewById(R.id.result2);

        rollTheDice.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                rollTheDice();
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dice1.setImageResource(R.drawable.empty_dice);
                dice2.setImageResource(R.drawable.empty_dice);
            }
        });

        dice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contador[0] =(int) (Math.random() *6 + 1);

                switch (contador[0]) {
                    case 1:
                        dice1.setImageResource(R.drawable.dice_1);
                        break;
                    case 2:
                        dice1.setImageResource(R.drawable.dice_2);
                        break;
                    case 3:
                        dice1.setImageResource(R.drawable.dice_3);
                        break;
                    case 4:
                        dice1.setImageResource(R.drawable.dice_4);
                        break;
                    case 5:
                        dice1.setImageResource(R.drawable.dice_5);
                        break;
                    case 6:
                        dice1.setImageResource(R.drawable.dice_6);
                        break;
                }
                jackpot();
            }
        });

        dice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contador[1] =(int) (Math.random() *6 + 1);

                switch (contador[1]) {
                    case 1:
                        dice2.setImageResource(R.drawable.dice_1);
                        break;
                    case 2:
                        dice2.setImageResource(R.drawable.dice_2);
                        break;
                    case 3:
                        dice2.setImageResource(R.drawable.dice_3);
                        break;
                    case 4:
                        dice2.setImageResource(R.drawable.dice_4);
                        break;
                    case 5:
                        dice2.setImageResource(R.drawable.dice_5);
                        break;
                    case 6:
                        dice2.setImageResource(R.drawable.dice_6);
                        break;
                }
                jackpot();
            }
        });

    }

    public void rollTheDice(){

        ImageView[] dices = {dice1, dice2};


        int i = 0;

        while (i < dices.length) {
            contador[i] = (int) (Math.random() * 6 + 1);
            switch (contador[i]) {
                case 1:
                    dices[i].setImageResource(R.drawable.dice_1);
                    break;
                case 2:
                    dices[i].setImageResource(R.drawable.dice_2);
                    break;
                case 3:
                    dices[i].setImageResource(R.drawable.dice_3);
                    break;
                case 4:
                    dices[i].setImageResource(R.drawable.dice_4);
                    break;
                case 5:
                    dices[i].setImageResource(R.drawable.dice_5);
                    break;
                case 6:
                    dices[i].setImageResource(R.drawable.dice_6);
                    break;
            }
            i++;
        }
        jackpot();
    }

    public void jackpot(){
        if (contador[0] == 6 && contador[1] == 6) {
            toast = Toast.makeText( getApplicationContext(),"JACKPOT!", LENGTH_SHORT);
            toast.setGravity(Gravity.TOP,0,0);
            toast.show();
        }
    }

}